<?php require_once("includes/init.php") ?>
<?php
    if(isset($_SESSION['user_id'])){
      $enrollments = Enrollment::find_user_enrollments($_SESSION['user_id']);
      $enrolled = Enrollment::find_user_enrolled($_SESSION['user_id']);
      $waitlisted = Enrollment::find_user_waitlist($_SESSION['user_id']);
      $completed = Enrollment::find_user_completed($_SESSION['user_id']);
      $dropped = Enrollment::find_user_dropped($_SESSION['user_id']);
    }
 ?>
 <?php $message = null ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width, initial-scale=1">
    <title>My Courses</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  </head>
  <body>

    <?php
      require 'includes/master.inc.php';

      $enrollment_user_id = '';
      $enrollment_course_id = '';
      $enrollment_id = '';

      if (isset($_POST['drop-button'])) {
        $ok = true;
        if (!isset($_POST['enrollment-user-id']) || $_POST['enrollment-user-id'] === '') {
            $ok = false;
        } else {
            $enrollment_user_id = $_POST['enrollment-user-id'];
        }
        if (!isset($_POST['enrollment-course-id']) || $_POST['enrollment-course-id'] === '') {
            $ok = false;
        } else {
            $enrollment_course_id = $_POST['enrollment-course-id'];
        }
        if (!isset($_POST['enrollment-id']) || $_POST['enrollment-id'] === '') {
            $ok = false;
        } else {
            $enrollment_id = $_POST['enrollment-id'];
        }
        //I will need to update these fields
        if ($ok) {
            $input_end = now();
            $sql = "UPDATE tbl_enrollments SET enrollment_status = 'Dropped', enrollment_end = $input_end, enrollment_waitlist = null WHERE enrollment_id = $enrollment_id";
            //$DB->executeQuery($sql);
            $sql = "UPDATE tbl_courses SET course_waitlist = course_waitlist - 1 WHERE course_id = $enrollment_course_id";
            //$DB->executeQuery($sql);
            //echo '<p>Account Added.</p>';
            //echo $sql;
            redirect('enrollments.php');
        }
      }

      if (isset($_POST['enroll-button'])) {
        $ok = true;
        if (!isset($_POST['enrollment-user-id']) || $_POST['enrollment-user-id'] === '') {
            $ok = false;
        } else {
            $enrollment_user_id = $_POST['enrollment-user-id'];
        }
        if (!isset($_POST['enrollment-course-id']) || $_POST['enrollment-course-id'] === '') {
            $ok = false;
        } else {
            $enrollment_course_id = $_POST['enrollment-course-id'];
        }
        if (!isset($_POST['enrollment-id']) || $_POST['enrollment-id'] === '') {
            $ok = false;
        } else {
            $enrollment_id = $_POST['enrollment-id'];
        }

          $sql = "UPDATE tbl_courses SET (course_enrollments = course_enrollments + 1, course_waitlist = course_waitlist - 1) WHERE course_id = $enrollment_course_id";
          $sql2 = "UPDATE tbl_enrollments SET enrollment_status = 'Enrolled', enrollment_course_Stitle = WHERE user_id = $input_courseID AND course_id = $input_courseID";
         $DB->executeQuery($sql);
         $DB->executeQuery($sql2);
        echo  "ENROLL: ";
        echo $sql;
        echo "</br>";
        //redirect('enrollments.php');

      }

    ?>
    <div id="page-wrapper">

                  <div class="container-fluid">

                      <!-- Waitlist Heading -->
                      <div class="row">
                          <div class="col-lg-12">
                              <h1 class="page-header">
                                  Enrollments
                                  <small>Waitlist</small>
                              </h1>
                              <div style='display: inline-block;'>
                                <p class="btn-success"><?php echo $message; ?> </p>
                              </div>
                              <br />
                              <div class="col-md-12">
                                <table class="table table-hover">
                                  <thead>
                                    <tr>
                                      <th>Action</th>
                                      <th>Enrollment ID</th>
                                      <th>Course ID</th>
                                      <th>Status</th>
                                      <th>Waitlist #</th>
                                      <th>Start</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                      foreach ($waitlisted as $waitlist) : ?>
                                      <form method="post" action="">
                                        <tr>
                                      <?php

                                          $enroll_or_drop = "drop";
                                          $button_class_toggle = 'danger'; //danger or sucess for btn-danger or btn-success
                                          if($waitlist->course_enrollments < $waitlist->course_capacity && $waitlist->enrollment_waitlist === 1){
                                            $enroll_or_drop = "enroll";
                                            $button_class_toggle = 'success';
                                          }

                                       ?>
                                       <input type="hidden" name="$enrollment-user-id" value="<?php echo $waitlist->$enrollment_user_id ?>">
                                       <input type="hidden" name="enrollment-course-id" value="<?php echo $waitlist->course_id ?>">
                                       <input type="hidden" name="enrollment-id" value="<?php echo $waitlist->enrollment_id ?>">
                                       <input type="hidden" name="enrollment-id" value="<?php echo $waitlist->enrollment_course_Stitle ?>">
                                       <input type="hidden" name="enrollment-id" value="<?php echo $waitlist->enrollment_waitlist ?>">
                                          <td>
                                              <input
                                              name="<?php $enroll_or_drop ?>-button"
                                              type="submit"
                                              value="<?php echo ucfirst($enroll_or_drop) ?> <?php echo $waitlist->course_Stitle ?>" class="btn btn-<?php echo $button_class_toggle?>"></td>
                                          <td><?php echo $waitlist->enrollment_id ?></td>
                                          <td><?php echo $waitlist->course_id ?></td>
                                          <td><?php echo $waitlist->enrollment_status ?></td>
                                          <td><?php echo $waitlist->enrollment_waitlist ?></td>
                                          <td><?php echo $waitlist->enrollment_start ?></td>

                                        </tr>
                                    <?php endforeach; ?>
                                  </tbody>
                                </table>
                              </div>
                          </div>
                      </div>
                      <!-- /.row -->

                      <!-- Emrollment Heading -->
                      <div class="row">
                          <div class="col-lg-12">
                              <h1 class="page-header">
                                  Enrollments
                                  <small>Active</small>
                              </h1>
                              <div style='display: inline-block;'>
                                <p class="btn-success"><?php echo $message; ?> </p>
                              </div>
                              <br />
                              <div class="col-md-12">
                                <table class="table table-hover">
                                  <thead>
                                    <tr>
                                      <th>Action</th>
                                      <th>Enrollment ID</th>
                                      <th>Course ID</th>
                                      <th>Status</th>
                                      <th>Grade</th>
                                      <th>Start</th>
                                      <th>End</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                      foreach ($enrolled as $enrollment) : ?>
                                      <form method="post" action="">
                                        <tr>
                                          <td><input name="drop-button" type="submit" value="Drop <?php echo $enrollment->course_Stitle ?>" class="btn btn-danger"></td>
                                          <td><?php echo $enrollment->enrollment_id ?></td>
                                          <td><?php echo $enrollment->course_id ?></td>
                                          <td><?php echo $enrollment->enrollment_status ?></td>
                                          <td><?php echo $enrollment->enrollment_grade ?></td>
                                          <td><?php echo $enrollment->enrollment_start ?></td>
                                          <td><?php echo $enrollment->enrollment_end ?></td>

                                        </tr>
                                    <?php endforeach; ?>
                                  </tbody>
                                </table>
                              </div>
                          </div>
                      </div>
                      <!-- /.row -->

                      <!-- Enrollments Completed / Dropped Heading-->
                      <div class="row">
                          <div class="col-lg-12">
                              <h1 class="page-header">
                                  Enrollments
                                  <small>Dropped</small>
                              </h1>
                              <div style='display: inline-block;'>
                                <p class="btn-success"><?php echo $message; ?> </p>
                              </div>
                              <br />
                              <div class="col-md-12">
                                <table class="table table-hover">
                                  <thead>
                                    <tr>
                                      <th>Enrollment ID</th>
                                      <th>Course ID</th>
                                      <th>Status</th>
                                      <th>Grade</th>
                                      <th>Start</th>
                                      <th>End</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                      foreach ($dropped as $enrollment) : ?>
                                      <form method="post" action="">
                                        <tr>
                                          <td><?php echo $enrollment->enrollment_id ?></td>
                                          <td><?php echo $enrollment->course_id ?></td>
                                          <td><?php echo $enrollment->enrollment_status ?></td>
                                          <td><?php echo $enrollment->enrollment_grade ?></td>
                                          <td><?php echo $enrollment->enrollment_start ?></td>
                                          <td><?php echo $enrollment->enrollment_end ?></td>

                                        </tr>
                                    <?php endforeach; ?>
                                  </tbody>
                                </table>
                              </div>
                          </div>
                      </div>
                      <!-- /.row -->

                      <!-- Enrollments Completed  Heading-->
                      <div class="row">
                          <div class="col-lg-12">
                              <h1 class="page-header">
                                  Enrollments
                                  <small>Completed</small>
                              </h1>
                              <div style='display: inline-block;'>
                                <p class="btn-success"><?php echo $message; ?> </p>
                              </div>
                              <br />
                              <div class="col-md-12">
                                <table class="table table-hover">
                                  <thead>
                                    <tr>
                                      <th>Enrollment ID</th>
                                      <th>Course ID</th>
                                      <th>Status</th>
                                      <th>Grade</th>
                                      <th>Start</th>
                                      <th>End</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                      foreach ($completed as $enrollment) : ?>
                                      <form method="post" action="">
                                        <tr>
                                          <td><?php echo $enrollment->enrollment_id ?></td>
                                          <td><?php echo $enrollment->course_id ?></td>
                                          <td><?php echo $enrollment->enrollment_status ?></td>
                                          <td><?php echo $enrollment->enrollment_grade ?></td>
                                          <td><?php echo $enrollment->enrollment_start ?></td>
                                          <td><?php echo $enrollment->enrollment_end ?></td>

                                        </tr>
                                    <?php endforeach; ?>
                                  </tbody>
                                </table>
                              </div>
                          </div>
                      </div>
                      <!-- /.row -->
                  </div>
                  <!-- /.container-fluid -->

    </div>



    <div>

    </div>

    <?php require_once 'includes/footer.inc.php'?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

  </body>
</html>
