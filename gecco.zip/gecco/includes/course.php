<?php

class Course{

  public $course_id;
  public $course_Ltitle;
  public $course_Stitle;
  public $course_preq1;
  public $course_preq2;
  public $course_preq3;
  public $course_desc;
  public $course_department;
  public $course_instr;
  public $course_capacity;
  public $course_start;
  public $course_end;
  public $course_semester;
  public $course_credits;
  public $course_enrollments;
  public $course_waitlist;

  private static $courseCount;

  public static function find_all_courses(){
    return self::find_this_query("SELECT * FROM tbl_courses");
  }

  public static function find_course_semesters(){
    return self::find_this_query("SELECT DISTINCT course_semester FROM tbl_courses ORDER BY course_start");
  }

  public static function find_courses_by_semester($semester){
    return self::find_this_query("SELECT * FROM tbl_courses WHERE course_semester = $semester");
  }

  public static function get_course_capacity($lookup_id){
    return self::find_this_query("SELECT course_capacity FROM tbl_courses WHERE course_id = $lookup_id LIMIT 1");
  }

  public static function get_course_enrollments($lookup_id){
    return self::find_this_query("SELECT course_enrollments from tbl_courses WHERE course_id = $lookup_id LIMIT 1");
  }

  public static function find_course_by_id($lookup_id){
    global $DB;
    $result_array = self::find_this_query("SELECT * FROM tbl_courses WHERE course_id = $lookup_id LIMIT 1");

    //make sure that array isn't empty
    // if(!empty($result_array)){
    //   $first_item = array_shift($result_array);
    //   return $first_item;
    // } else {
    //   return false;
    // }
    //same as the above
    return !empty($result_array) ? array_shift($result_array) : false;
  }

  public static function find_this_query($sql){
    global $DB;
    $result_set = $DB->executeSelectQuery($sql);

    $the_object_array = [];
    while($row = mysqli_fetch_array($result_set)){
      $the_object_array[] = self::instantiation($row);
    }
    return $the_object_array;
  }

  public static function instantiation($the_record){
    $the_object = new self;

    foreach ($the_record as $the_attribute => $value) {
      if($the_object->has_the_attribute($the_attribute)){
        $the_object->$the_attribute = $value;
      }

    }

    return $the_object;
  }

  private function has_the_attribute($the_attribute){
    //returns array of all object vars
    $object_properties = get_object_vars($this);

    //returns true if arg1 in arg2
    return array_key_exists($the_attribute, $object_properties);
  }

  public static function ajax_display_course_data($course_id){

    $course = Course::find_course_by_id($course_id);
    $output .= "<p>{$course->course_Stitle} | {$course->course_Semester}</p>";
    $output .= "<p>{$course->course_Ltitle}</p>";
    $output .= "<p>Credit Hours: {$course->course_credits}</p>";
    $output .= "<p>Prerequisites: {$course->course_preq1} {$course->course_preq1} {$course->course_preq1}</p>";
    $output .= "<p>Instructor: {$course->course_instr}</p>";
    $output .= "<p>Capacity: {$course->course_capacity}</p>";
    $output .= "<p>Start: {$course->course_start}</p>";
    $output .= "<p>End: {$course->course_end}</p>";
    $output .= "<p>{$course->course_desc}</p>";

    echo $output;


  }//End of ajax_display_photo_data() Method
}

?>
<!--   public $course_id;
  public $course_preq1;
  public $course_preq2;
  public $course_preq3;
  public $course_desc;

  public $course_semester;
  public $course_credits;-->
