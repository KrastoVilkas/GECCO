<?php
// Database COnnection Constants
define('DBHOST','localhost');
define('DBUSER','root');
define('DBPASS','');
define('DBNAME','db_gecco');
?>
