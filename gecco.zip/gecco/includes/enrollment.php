<?php

class Enrollment{

  public $enrollment_id;
  public $enrollment_user_id;
  public $course_id;
  public $course_Stitle;
  public $course_enrollments;
  public $course_capacity;
  public $enrollment_waitlist; //default is 0, indicating no waitlist
  public $enrollment_status;  //waitlist, enrolled, dropped
  public $enrollment_grade;   //not utilized
  public $enrollment_start;   //need to implement timestamp on front end when enroll
  public $enrollment_end; //default 0

  private static $enrollments_Count;

  public static function find_user_enrollments($user_id){
    return self::find_this_query("SELECT * FROM tbl_enrollments WHERE user_id = $user_id");
  }

  public static function find_user_enrolled($user_id){
    return self::find_this_query("SELECT * FROM tbl_enrollments WHERE user_id = $user_id AND enrollment_status = 'Enrolled'");
  }

  public static function find_user_waitlist($user_id){
    return self::find_this_query("SELECT * FROM tbl_enrollments WHERE user_id = $user_id AND enrollment_status = 'Waitlist'");
  }

  public static function find_user_dropped($user_id){
    return self::find_this_query("SELECT * FROM tbl_enrollments WHERE user_id = $user_id AND enrollment_status = 'Dropped'");
  }

  public static function find_user_completed($user_id){
    return self::find_this_query("SELECT * FROM tbl_enrollments WHERE user_id = $user_id AND enrollment_status = 'Completed'");
  }

  public static function find_user_first_on_waitlist($user_id){
    return self::find_this_query("SELECT * FROM tbl_enrollments WHERE user_id = $user_id AND enrollment_waitlist = 1");
  }

  public static function find_enrollment_by_id($lookup_id){
    global $DB;
    $result_array = self::find_this_query("SELECT * FROM tbl_enrollments WHERE enrollment_id = $lookup_id LIMIT 1");

    //make sure that array isn't empty
    // if(!empty($result_array)){
    //   $first_item = array_shift($result_array);
    //   return $first_item;
    // } else {
    //   return false;
    // }
    //same as the above
    return !empty($result_array) ? array_shift($result_array) : false;
  }

  public static function find_this_query($sql){
    global $DB;
    $result_set = $DB->executeSelectQuery($sql);

    $the_object_array = [];
    while($row = mysqli_fetch_array($result_set)){
      $the_object_array[] = self::instantiation($row);
    }
    return $the_object_array;
  }

  public static function instantiation($the_record){
    $the_object = new self;

    foreach ($the_record as $the_attribute => $value) {
      if($the_object->has_the_attribute($the_attribute)){
        $the_object->$the_attribute = $value;
      }

    }

    return $the_object;
  }

  private function has_the_attribute($the_attribute){
    //returns array of all object vars
    $object_properties = get_object_vars($this);

    //returns true if arg1 in arg2
    return array_key_exists($the_attribute, $object_properties);
  }

  public static function ajax_display_enrollment_data($enrollment_id){

    $course = Enrollment::find_enrollment_by_id($enrollment_id);
    $output .= "<p>User ID {$enrollment->enrollment_user_id}</p>";
    $output .= "<p>Course Title {$enrollment->enrollment_course_Stitle}</p>";
    $output .= "<p>Waitlist:{$enrollment->enrollment_course_id}</p>";
    $output .= "<p>Status{$enrollment->enrollment_course_id}</p>";
    $output .= "<p>Grade: {$enrollment->enrollment_course_id}</p>";
    $output .= "<p>Start: {$enrollment->enrollment_course_id}</p>";
    $output .= "<p>End: {$enrollment->enrollment_course_id}</p>";

    echo $output;

  }//End of ajax_display_enrollment_data() Method
}

?>


<!--   public $course_id;
  public $course_preq1;
  public $course_preq2;
  public $course_preq3;
  public $course_desc;

  public $course_semester;
  public $course_credits;-->
