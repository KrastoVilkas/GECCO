<?php require_once("includes/init.php") ?>
<?php $courses = Course::find_all_courses(); ?>
<?php $semesters = Course::find_course_semesters(); ?>
<?php $filter = "All Semesters"; ?>
<?php
    if(isset($_SESSION['user_id'])){
      $userID = $_SESSION['user_id'];
      $enrollments = Enrollment::find_user_enrollments($_SESSION['user_id']);
    } else {
      $enrollments = null;
    }
 ?>
<?php $message = null ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width, initial-scale=1">
    <title>Courses</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  </head>
  <body>
    <?php

    require 'includes/master.inc.php';

    $input_courseID = '';
    $input_userID = '';
    $input_waitlist = null;
    $input_status = '';
    $input_course_Stitle = '';
    $count = null;

    if(isset($_POST['enroll-button'])) {
      $course_waitlist =
      $ok = true;
      if (!isset($_POST['input-courseID']) || $_POST['input-courseID'] === '') {
          $ok = false;
      } else {
          $input_courseID = $_POST['input-courseID'];
      }
      if (!isset($_POST['input-userID']) || $_POST['input-userID'] === '') {
          $ok = false;
      } else {
          $input_userID = $_POST['input-userID'];
      }
      if (!isset($_POST['input-status']) || $_POST['input-status'] === '') {
          $ok = false;
      } else {
          $input_status = $_POST['input-status'];
      }
      if (!isset($_POST['input-waitlist']) || $_POST['input-waitlist'] === '') {
          $ok = false;
      } else {
          $input_waitlist = $_POST['input-waitlist'];
      }
      if (!isset($_POST['input-course-Stitle']) || $_POST['input-course-Stitle'] === '') {
          $ok = false;
      } else {
          $input_course_Stitle = $_POST['input-course-Stitle'];
      }

      //$input_course_Stitle = "''" . $input_course_Stitle . "''";

      //insert enrollment with status
      $sql = sprintf("INSERT INTO tbl_enrollments (user_id, course_id, course_Stitle, enrollment_status, enrollment_waitlist) VALUES (
      '%s', '%s', '%s', '%s', '%s')",
        $DB->escape_string($input_userID),
        $DB->escape_string($input_courseID),
        $DB->escape_string($input_course_Stitle),
        $DB->escape_string($input_status),
        $DB->escape_string($input_waitlist));
      $DB->executeQuery($sql);

        echo "EXECUTE: ";
        echo $sql;
        echo "</br>";
        echo "INPUT STATUS: " . $input_status;
        echo "</br>";


      //If enrolling, increment associated course_enrollments
      if ($input_status === "Enrolled"){
        echo "potato";
        $sql = "UPDATE tbl_courses SET course_enrollments = course_enrollments + 1 WHERE course_id = $input_courseID";
        $sql2 = "UPDATE tbl_enrollments SET enrollment_status = 'Enrolled', enrollment_course_Stitle = WHERE user_id = $input_courseID AND course_id = $input_courseID";
       $DB->executeQuery($sql);
       $DB->executeQuery($sql2);
      echo  "ENROLL: ";
      echo $sql;
      echo "</br>";
      //redirect('courses.php');
      }

      //if waitlisting, increment associated course_waitlist and
      if ($input_status === "Waitlist"){
        $input_waitlist += 1;
        $sql = "UPDATE tbl_courses SET course_waitlist = $input_waitlist WHERE course_id = $input_courseID";
        $DB->executeQuery($sql);
        $sql = "UPDATE tbl_enrollments SET enrollment_status = 'Waitlist', enrollment_waitlist = $input_waitlist WHERE user_id = $input_courseID AND course_id = $input_courseID";
        $DB->executeQuery($sql);
            //echo "WAITLSIT";
            //echo $sql;
            //echo "</br>";
        //redirect('courses.php');

      }
    }
    ?>
<div id="page-wrapper">

              <div class="container-fluid">

                  <!-- Page Heading -->
                  <div class="row">
                      <div class="col-lg-12">
                          <h1 class="page-header">
                              Courses
                              <small><?php echo $filter ?></small>
                          </h1>
                          <div style='display: inline-block;'>
                            <?php
                              foreach ($semesters as $semester) : ?>
                              <form method="post" action="submit">
                                <td>
                                  <button type="submit" name="filter-id" value="<?php echo $semester->course_semester ?>" class="btn btn-secondary filter-button"><?php echo $semester->course_semester ?></button>
                                </td>
                             </form>
                            <?php endforeach; ?>
                            <p class="btn-success"><?php echo $message; ?> </p>
                          </div>
                          <br />
                          <div class="col-md-12">
                            <table class="table table-hover">
                              <thead>
                                <tr>
                                  <th>Action</th>
                                  <th>Course ID</th>
                                  <th>Course</th>
                                  <th>Title</th>
                                  <th>Description</th>
                                  <th>Department</th>
                                  <th>Instructor</th>
                                  <th>Capacity</th>
                                  <th>Prerequisites</th>
                                  <th>Start/End</th>
                                  <th>Semester</th>
                                  <th>Credits</th>
                                  <th>Enrollments</th>
                                  <th>Waitlist</th>
                                </tr>
                              </thead>
                              <tbody>

                                <?php
                                  foreach ($courses as $course) : ?>
                                    <tr class="<?php $course_semester ?>">
                                      <td>
                                            <form method="post" action="">
                                            <input type="hidden" name="input-courseID" value="<?php echo $course->course_id; ?>">
                                            <input type="hidden" name="input-userID" value="<?php echo $userID; ?>">
                                            <input type="hidden" name="input-waitlist" value="<?php echo $course->course_waitlist; ?>">
                                            <input type="hidden" name="input-course-Stitle" value="<?php echo $course->course_Stitle; ?>">
                                            <input type="hidden"
                                                   name="input-status" value="<?php if ($course->course_enrollments < $course->course_capacity) {
                                                     echo "Enrolled";
                                                   } else {
                                                     echo "Waitlist";
                                                   } ?>">
                                            <input
                                              type="submit"
                                              name="enroll-button"
                                              value="<?php if ($course->course_enrollments < $course->course_capacity) {
                                                echo "Enroll ";
                                              } else {
                                                echo "Waitlist ";
                                              } echo $course->course_Stitle ?>"
                                              class="btn btn-success">
                                            </form>
                                      </td>
                                      <td><?php echo $course->course_id ?></td>
                                      <td><?php echo $course->course_Stitle ?></td>
                                      <td><?php echo $course->course_Ltitle ?></td>
                                      <td><?php echo $course->course_desc ?></td>
                                      <td><?php echo $course->course_department ?></td>
                                      <td><?php echo $course->course_instr ?></td>
                                      <td><?php echo $course->course_capacity ?></td>
                                      <td><?php echo $course->course_preq1 ?> | <?php echo $course->course_preq2 ?> | <?php echo $course->course_preq3 ?></td>
                                      <td><?php echo $course->course_start?> / <?php echo $course->course_end ?></td>
                                      <td><?php echo $course->course_semester ?></td>
                                      <td><?php echo $course->course_credits ?></td>
                                      <td><?php echo $course->course_enrollments ?></td>
                                      <td><?php echo $course->course_waitlist ?></td>
                                    </tr>

                                <?php endforeach; ?>
                              </tbody>
                            </table>
                          </div>
                      </div>
                  </div>
                  <!-- /.row -->

              </div>
              <!-- /.container-fluid -->

</div>

<!-- /#page-wrapper -->


    <?php require_once 'includes/footer.inc.php'?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

  </body>
</html>
