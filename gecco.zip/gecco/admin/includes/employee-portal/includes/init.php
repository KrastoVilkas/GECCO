<?php  require_once("db.php");?>
<?php  require_once("user.php");?>
<?php  require_once("session.php");?>
<?php  require_once("functions.php");?>
