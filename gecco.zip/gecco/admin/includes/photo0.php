<?php

class Photo extends Db_object{

  protected static $db_table = "tbl_courses";
  protected static $db_table_fields = array("id","course_Ltitle","course_Stitle","course_preq1","course_preq2","course_preq3","course_desc","course_department","course_instr","course_capacity","coourse_start","course_end","course_semester","course_credits");
  public $id;
  public $course_Ltitle;
  public $course_Stitle;
  public $course_preq1;
  public $course_preq2;
  public $course_preq3;
  public $course_desc;
  public $course_department;
  public $course_instr;
  public $course_capacity;
  public $course_start;
  public $course_end;
  public $course_semester;
  public $course_credits;

    public function check_empty_props(){
    if($this->course_Ltitle === "" || empty($this->course_Ltitle)){
      $this->course_Ltitle = $this->course_Stitle;
    }
    if($this->course_desc === "" || empty($this->course_desc)){
      $this->course_desc = "No description provided.";
    }
  }

}//End of Course Class
 ?>
